package com.demo.configserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
